export type BadgeId =
  | "flashcard-master"
  | "grammar-warrior"
  | "daily-streak-7"
  | "ai-friend"
  | "category-explorer"
  | "speed-learner"
  | "super-hard-learner"
  | "level-5"
  | "level-10"
  | "level-20"

export interface Badge {
  id: BadgeId
  title: string
  description: string
  icon: string
  requirement: number
  type: "cards" | "categories" | "streak" | "ai" | "level" | "speed"
}

export const BADGES: Record<BadgeId, Badge> = {
  "flashcard-master": {
    id: "flashcard-master",
    title: "Flashcard Master",
    description: "Flip 50 cards",
    icon: "🎴",
    requirement: 50,
    type: "cards",
  },
  "grammar-warrior": {
    id: "grammar-warrior",
    title: "Grammar Warrior",
    description: "Complete Grammar category",
    icon: "⚔️",
    requirement: 1,
    type: "categories",
  },
  "daily-streak-7": {
    id: "daily-streak-7",
    title: "🔥 Focus Mode",
    description: "7 day learning streak",
    icon: "🔥",
    requirement: 7,
    type: "streak",
  },
  "ai-friend": {
    id: "ai-friend",
    title: "AI Friend",
    description: "Ask AI for help 10 times",
    icon: "🤖",
    requirement: 10,
    type: "ai",
  },
  "category-explorer": {
    id: "category-explorer",
    title: "Category Explorer",
    description: "Complete 5 different categories",
    icon: "🗺️",
    requirement: 5,
    type: "categories",
  },
  "speed-learner": {
    id: "speed-learner",
    title: "Speed Learner",
    description: "Complete 10 cards in 5 minutes",
    icon: "⚡",
    requirement: 10,
    type: "speed",
  },
  "super-hard-learner": {
    id: "super-hard-learner",
    title: "Super Hard Learner",
    description: "Complete Hard Mode on any category",
    icon: "💎",
    requirement: 1,
    type: "categories",
  },
  "level-5": {
    id: "level-5",
    title: "Rising Star",
    description: "Reach Level 5",
    icon: "⭐",
    requirement: 5,
    type: "level",
  },
  "level-10": {
    id: "level-10",
    title: "Expert Learner",
    description: "Reach Level 10",
    icon: "🌟",
    requirement: 10,
    type: "level",
  },
  "level-20": {
    id: "level-20",
    title: "Master Scholar",
    description: "Reach Level 20",
    icon: "👑",
    requirement: 20,
    type: "level",
  },
}
