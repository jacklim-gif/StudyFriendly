// 5. Database Structure for Categories + Levels + Questions
export type Level = "easy" | "normal" | "hard"
export type CategoryId =
  | "travel"
  | "interview"
  | "school"
  | "food"
  | "daily-speaking"
  | "slang"
  | "grammar"
  | "academic"
  | "email"
  | "phone"
  | "directions"
  | "shopping"
  | "workplace"
  | "manglish"
  | "greetings"
  | "home"
  | "health"
  | "emergency"
  | "technology"
  | "banking"
  | "hotel"
  | "airport"

export interface Question {
  q: string
  a: string
}

export interface CategoryData {
  id: CategoryId
  title: string
  subtitle: string
  icon: string
  levels: Record<Level, Question[]>
}

export const STUDY_DATA: Record<CategoryId, CategoryData> = {
  greetings: {
    id: "greetings",
    title: "Basic Greetings",
    subtitle: "Start a conversation.",
    icon: "👋",
    levels: {
      easy: [
        { q: "What is your name?", a: "My name is ___." },
        { q: "How are you?", a: "I'm fine, thank you." },
        { q: "Where are you from?", a: "I'm from ___." },
        { q: "Thank you.", a: "You're welcome." },
        { q: "Good morning.", a: "Good morning." },
      ],
      normal: [
        { q: "Nice to meet you.", a: "Nice to meet you too." },
        { q: "See you later.", a: "Goodbye / See you." },
        { q: "Excuse me.", a: "Used to get attention or apologize." },
        { q: "I am sorry.", a: "Apology for a mistake." },
        { q: "Do you speak English?", a: "Asking about language ability." },
      ],
      hard: [
        { q: "It's a pleasure to meet you.", a: "Formal greeting." },
        { q: "How have you been?", a: "Asking about recent past." },
        { q: "I appreciate it.", a: "Formal way to say thank you." },
        { q: "Forgive me for the interruption.", a: "Formal apology." },
        { q: "I look forward to seeing you again.", a: "Formal closing." },
      ],
    },
  },
  travel: {
    id: "travel",
    title: "Travel",
    subtitle: "Navigate the world.",
    icon: "✈️",
    levels: {
      easy: [
        { q: "Where is the exit?", a: "Exit is over there." },
        { q: "One ticket please.", a: "I want 1 ticket." },
        { q: "Where is the bathroom?", a: "Restroom location." },
        { q: "Map please.", a: "Asking for a map." },
        { q: "Bus stop?", a: "Where is the bus?" },
      ],
      normal: [
        { q: "What time is the train?", a: "The train is at ___." },
        { q: "Is this the right way to ___?", a: "Checking directions." },
        { q: "How far is it?", a: "Asking for distance." },
        { q: "I would like to check in.", a: "Hotel arrival." },
        { q: "Can you take a photo of us?", a: "Asking for a picture." },
      ],
      hard: [
        { q: "My luggage is missing.", a: "Reporting lost bags." },
        { q: "I need to change my reservation.", a: "Modifying plans." },
        { q: "Is there a penalty for cancellation?", a: "Asking about fees." },
        { q: "Could you recommend a local spot?", a: "Asking for advice." },
        { q: "I seem to be lost.", a: "Admitting you need help." },
      ],
    },
  },
  interview: {
    id: "interview",
    title: "Interview",
    subtitle: "Ace your next job application.",
    icon: "💼",
    levels: {
      easy: [
        { q: "Tell me about yourself.", a: "Briefly introduce your professional background." },
        { q: "What is your greatest strength?", a: "Highlight a skill relevant to the job." },
      ],
      normal: [
        { q: "Why do you want to leave your current job?", a: "Focus on seeking new challenges, not negativity." },
        { q: "Where do you see yourself in 5 years?", a: "Discuss career growth and ambition." },
      ],
      hard: [
        { q: "Describe a time you failed and how you handled it.", a: "STAR method: Situation, Task, Action, Result." },
        { q: "How do you handle conflict with a coworker?", a: "Focus on communication and resolution." },
      ],
    },
  },
  school: {
    id: "school",
    title: "School & Study",
    subtitle: "Classroom language.",
    icon: "🎓",
    levels: {
      easy: [
        { q: "What chapter is this?", a: "Which chapter?" },
        { q: "How to spell this?", a: "Spell it." },
        { q: "I need practice.", a: "More exercises." },
        { q: "May I go to the toilet?", a: "Permission to leave." },
        { q: "I forgot my book.", a: "Missing item." },
      ],
      normal: [
        { q: "When is the exam?", a: "Test date." },
        { q: "Can I borrow a pen?", a: "Lending request." },
        { q: "I don't understand the question.", a: "Confusion." },
        { q: "Is this correct?", a: "Checking work." },
        { q: "Please repeat.", a: "Asking teacher to say again." },
      ],
      hard: [
        { q: "What is the due date?", a: "Assignment deadline." },
        { q: "Can I get extra credit?", a: "Bonus points." },
        { q: "I was absent yesterday.", a: "Missing class." },
        { q: "Can you explain the concept?", a: "Deep question." },
        { q: "I'm preparing for finals.", a: "Exam prep." },
      ],
    },
  },
  food: {
    id: "food",
    title: "Restaurant & Food",
    subtitle: "Order delicious meals.",
    icon: "🍔",
    levels: {
      easy: [
        { q: "I want to order.", a: "Can I order please?" },
        { q: "No sugar please.", a: "Less sweet." },
        { q: "Is this spicy?", a: "Hot or not?" },
        { q: "Water please.", a: "Asking for water." },
        { q: "Check please.", a: "Asking for the bill." },
      ],
      normal: [
        { q: "Can I see the menu?", a: "Requesting list of food." },
        { q: "I'm vegetarian.", a: "Dietary restriction." },
        { q: "What do you recommend?", a: "Asking for advice." },
        { q: "Takeaway please.", a: "To go." },
        { q: "Table for two.", a: "Seating request." },
      ],
      hard: [
        { q: "I'm allergic to nuts.", a: "Medical dietary warning." },
        { q: "Could we split the bill?", a: "Paying separately." },
        { q: "Is service included?", a: "Asking about tips." },
        { q: "This isn't what I ordered.", a: "Returning wrong food." },
        { q: "Compliments to the chef.", a: "Praising the food." },
      ],
    },
  },
  "daily-speaking": {
    id: "daily-speaking",
    title: "Daily Conversation",
    subtitle: "Everyday chats.",
    icon: "🗣️",
    levels: {
      easy: [
        { q: "What are you doing?", a: "I'm working/studying." },
        { q: "Can you repeat that?", a: "Say again please." },
        { q: "I don't understand.", a: "Please explain." },
        { q: "Yes, please.", a: "Accepting offer." },
        { q: "No, thank you.", a: "Declining offer." },
      ],
      normal: [
        { q: "Could you speak slower?", a: "Requesting slower speech." },
        { q: "What do you mean?", a: "Asking for clarification." },
        { q: "That sounds good.", a: "Agreeing with a plan." },
        { q: "I'm not sure.", a: "Expressing doubt." },
        { q: "Let me think about it.", a: "Delaying a decision." },
      ],
      hard: [
        { q: "I'm leaning towards option A.", a: "Expressing preference." },
        { q: "To be honest with you...", a: "Starting a frank statement." },
        { q: "That's a valid point.", a: "Agreeing in debate." },
        { q: "I beg to differ.", a: "Polite disagreement." },
        { q: "Let's agree to disagree.", a: "Ending an argument." },
      ],
    },
  },
  slang: {
    id: "slang",
    title: "Slang & Informal",
    subtitle: "Talk like a native.",
    icon: "💬",
    levels: {
      easy: [
        { q: "Cool!", a: "Expressing approval or agreement" },
        { q: "No way!", a: "Expressing surprise or disbelief" },
      ],
      normal: [
        { q: "That's lit!", a: "That's awesome/exciting (modern slang)" },
        { q: "I'm dead.", a: "Something is hilariously funny" },
      ],
      hard: [
        { q: "He ghosted me.", a: "Suddenly stopped communicating without explanation" },
        { q: "She's been flexing her new car.", a: "Showing off / bragging about something" },
      ],
    },
  },
  grammar: {
    id: "grammar",
    title: "Grammar",
    subtitle: "Master the rules.",
    icon: "📚",
    levels: {
      easy: [
        { q: "I am / I'm", a: "Present simple contraction of 'I am'" },
        { q: "He goes to school.", a: "Present simple - add 's' for third person" },
      ],
      normal: [
        { q: "If I were rich, I would travel.", a: "Second conditional - hypothetical present" },
        { q: "She has been working here for 5 years.", a: "Present perfect continuous - ongoing action" },
      ],
      hard: [
        { q: "Had I known earlier, I would have acted.", a: "Inverted conditional - formal structure" },
        { q: "No sooner had he arrived than it started raining.", a: "Inverted structure emphasizing sequence" },
      ],
    },
  },
  academic: {
    id: "academic",
    title: "Academic English",
    subtitle: "For scholars and students.",
    icon: "🎓",
    levels: {
      easy: [
        { q: "Therefore", a: "Transitional word showing result/conclusion" },
        { q: "In conclusion", a: "Phrase to begin final paragraph" },
      ],
      normal: [
        { q: "Moreover", a: "Adding information - more formal than 'also'" },
        { q: "The data suggests that...", a: "Academic way to present findings" },
      ],
      hard: [
        { q: "Notwithstanding the limitations...", a: "Despite/in spite of - very formal" },
        { q: "The study corroborates previous findings.", a: "Confirms/supports earlier research" },
      ],
    },
  },
  email: {
    id: "email",
    title: "Email Writing",
    subtitle: "Professional communication.",
    icon: "🧾",
    levels: {
      easy: [
        { q: "Dear [Name],", a: "Formal email greeting" },
        { q: "Best regards,", a: "Professional email closing" },
      ],
      normal: [
        { q: "I am writing to inquire about...", a: "Formal way to ask for information" },
        { q: "Thank you for your prompt response.", a: "Appreciating quick reply" },
      ],
      hard: [
        { q: "I would appreciate it if you could...", a: "Very polite request in formal context" },
        {
          q: "Please do not hesitate to contact me should you require further clarification.",
          a: "Offering availability - highly formal",
        },
      ],
    },
  },
  phone: {
    id: "phone",
    title: "Phone Conversation",
    subtitle: "Talk confidently on calls.",
    icon: "📞",
    levels: {
      easy: [
        { q: "Hello, this is [Name].", a: "Standard way to answer professionally" },
        { q: "Can I call you back later?", a: "Politely postponing the conversation" },
      ],
      normal: [
        { q: "May I speak with Mr. Johnson?", a: "Formal way to ask for someone" },
        { q: "I'll put you through.", a: "Transferring call to another person" },
      ],
      hard: [
        { q: "I'm afraid he's in a meeting. May I take a message?", a: "Professional unavailability response" },
        { q: "Could you please hold while I retrieve that information?", a: "Asking caller to wait professionally" },
      ],
    },
  },
  directions: {
    id: "directions",
    title: "Directions & Asking Help",
    subtitle: "Navigate any city.",
    icon: "🧭",
    levels: {
      easy: [
        { q: "Where is the train station?", a: "Basic direction question" },
        { q: "Turn left / Turn right", a: "Simple directional instructions" },
      ],
      normal: [
        { q: "How do I get to the museum from here?", a: "Asking for route guidance" },
        { q: "Is it walking distance?", a: "Asking if destination is reachable by foot" },
      ],
      hard: [
        { q: "Take the second left after the roundabout.", a: "Complex directional instruction" },
        { q: "It's about 200 meters past the intersection on your right.", a: "Precise location description" },
      ],
    },
  },
  shopping: {
    id: "shopping",
    title: "Shopping",
    subtitle: "Buy what you need.",
    icon: "🛍️",
    levels: {
      easy: [
        { q: "How much is this?", a: "Price please." },
        { q: "Do you have size M?", a: "I want size M." },
        { q: "Can I return this?", a: "Refund possible?" },
        { q: "Too expensive.", a: "Price is high." },
        { q: "I'll take it.", a: "Buying item." },
      ],
      normal: [
        { q: "Are you open?", a: "Checking store hours." },
        { q: "Where is the fitting room?", a: "Want to try on." },
        { q: "Do you accept card?", a: "Payment method." },
        { q: "Is this on sale?", a: "Discount question." },
        { q: "Just looking, thanks.", a: "Browsing." },
      ],
      hard: [
        { q: "Do you have this in stock?", a: "Checking inventory." },
        { q: "Can I get a receipt?", a: "Proof of purchase." },
        { q: "Does it come with a warranty?", a: "Guarantee question." },
        { q: "I'd like to exchange this.", a: "Swapping items." },
        { q: "Can you gift wrap it?", a: "Wrapping request." },
      ],
    },
  },
  workplace: {
    id: "workplace",
    title: "Work & Office",
    subtitle: "Professional tasks.",
    icon: "💼",
    levels: {
      easy: [
        { q: "When is the meeting?", a: "Meeting time?" },
        { q: "Can you help me?", a: "I need assistance." },
        { q: "Send me the file.", a: "Email me the document." },
        { q: "I'm busy.", a: "Not free now." },
        { q: "Good job.", a: "Praise." },
      ],
      normal: [
        { q: "I'm running late.", a: "Delayed arrival." },
        { q: "Let's reschedule.", a: "Change time." },
        { q: "Did you get my email?", a: "Checking communication." },
        { q: "I'm on leave tomorrow.", a: "Day off." },
        { q: "Can we talk briefly?", a: "Quick chat." },
      ],
      hard: [
        { q: "Please find attached.", a: "Email phrase." },
        { q: "Let's touch base later.", a: "Follow up phrase." },
        { q: "I have a deadline.", a: "Time limit constraint." },
        { q: "Who is in charge?", a: "Asking for leader." },
        { q: "We need to collaborate.", a: "Work together." },
      ],
    },
  },
  manglish: {
    id: "manglish",
    title: "Malaysian Manglish",
    subtitle: "Unique Malaysian English blend.",
    icon: "🇲🇾",
    levels: {
      easy: [
        { q: "Can or not?", a: "Is it possible? / Can you do it?" },
        { q: "Already lah!", a: "Expression of emphasis - 'It's done!'" },
      ],
      normal: [
        { q: "You go first lah, I follow behind.", a: "Offering to go second" },
        { q: "Alamak! I forgot!", a: "Expression of surprise/dismay (Malay influence)" },
      ],
      hard: [
        { q: "Don't like that lah, very the annoying one.", a: "Don't behave that way, it's very annoying" },
        { q: "Aiyah, you always like that, never change one!", a: "Expression of frustration - you never change!" },
      ],
    },
  },
  home: {
    id: "home",
    title: "Home & Daily Life",
    subtitle: "Household phrases.",
    icon: "🏠",
    levels: {
      easy: [
        { q: "Turn off the lights.", a: "Switch off." },
        { q: "Lock the door.", a: "Secure the house." },
        { q: "I'm cleaning.", a: "Doing housework." },
        { q: "Time to wake up.", a: "Morning call." },
        { q: "Go to sleep.", a: "Bedtime." },
      ],
      normal: [
        { q: "Can you take out the trash?", a: "Chore request." },
        { q: "Dinner is ready.", a: "Meal announcement." },
        { q: "Where is the remote?", a: "Looking for TV control." },
        { q: "The sink is leaking.", a: "Maintenance issue." },
        { q: "What's the weather like?", a: "Asking about climate." },
      ],
      hard: [
        { q: "Could you fix the TV remote?", a: "Repair request." },
        { q: "I need to buy groceries.", a: "Shopping task." },
        { q: "Can you help me move?", a: "Assistance needed." },
        { q: "I'm redecorating my room.", a: "Home improvement." },
        { q: "What time is dinner?", a: "Meal schedule." },
      ],
    },
  },
  health: {
    id: "health",
    title: "Health & Wellness",
    subtitle: "Maintain good health.",
    icon: "🏥",
    levels: {
      easy: [
        { q: "How are you feeling?", a: "I'm feeling well." },
        { q: "Can I have some water?", a: "Requesting hydration." },
        { q: "I'm tired.", a: "Expressing fatigue." },
        { q: "I need to take a break.", a: "Rest time." },
        { q: "I'm not feeling well.", a: "Health concern." },
      ],
      normal: [
        { q: "Do you have a bandage?", a: "First aid item." },
        { q: "Can you call an ambulance?", a: "Emergency help." },
        { q: "I need to schedule an appointment.", a: "Doctor visit." },
        { q: "What's your temperature?", a: "Health check." },
        { q: "I'm feeling dizzy.", a: "Symptom report." },
      ],
      hard: [
        { q: "I have a chronic condition.", a: "Long-term health issue." },
        { q: "Can you prescribe medication?", a: "Doctor's order." },
        { q: "I need to follow up on my test results.", a: "Health report." },
        { q: "I'm experiencing severe pain.", a: "Medical emergency." },
        { q: "I need to go to the hospital.", a: "Immediate medical attention." },
      ],
    },
  },
  emergency: {
    id: "emergency",
    title: "Emergency Situations",
    subtitle: "Handle unexpected events.",
    icon: "🚨",
    levels: {
      easy: [
        { q: "Is there a fire?", a: "Fire alert." },
        { q: "Can you call the police?", a: "Law enforcement request." },
        { q: "Where is the nearest hospital?", a: "Medical facility location." },
        { q: "I need help.", a: "Assistance required." },
        { q: "I'm lost.", a: "Direction confusion." },
      ],
      normal: [
        { q: "Do you have a first aid kit?", a: "Emergency medical supplies." },
        { q: "I need to report a crime.", a: "Police report." },
        { q: "Can you help me evacuate?", a: "Safety measure." },
        { q: "I'm trapped.", a: "Rescue needed." },
        { q: "I need to contact my family.", a: "Informing loved ones." },
      ],
      hard: [
        { q: "I'm experiencing a medical emergency.", a: "Urgent health situation." },
        { q: "Can you assist me with my passport?", a: "Travel document help." },
        { q: "I need to report a lost bag.", a: "Airline assistance." },
        { q: "I'm in a car accident.", a: "Traffic incident." },
        { q: "I need to contact my embassy.", a: "Government help." },
      ],
    },
  },
  technology: {
    id: "technology",
    title: "Technology",
    subtitle: "Stay connected.",
    icon: "📱",
    levels: {
      easy: [
        { q: "How do I turn on the phone?", a: "Press the power button." },
        { q: "Can I use your Wi-Fi?", a: "Internet request." },
        { q: "I need to charge my phone.", a: "Power connection." },
        { q: "What's the password?", a: "Access code." },
        { q: "I can't find my charger.", a: "Missing accessory." },
      ],
      normal: [
        { q: "Can you help me fix my computer?", a: "Technical assistance." },
        { q: "Do you have a printer?", a: "Document printing." },
        { q: "I need to download an app.", a: "Software installation." },
        { q: "Can you explain how this works?", a: "Device functionality." },
        { q: "I'm having trouble with my email.", a: "Communication issue." },
      ],
      hard: [
        { q: "I need to reset my router.", a: "Network configuration." },
        { q: "Can you help me with my programming?", a: "Coding assistance." },
        { q: "I need to update my software.", a: "System upgrade." },
        { q: "Can you help me with my social media?", a: "Online presence." },
        { q: "I need to troubleshoot my network.", a: "Internet connection issues." },
      ],
    },
  },
  banking: {
    id: "banking",
    title: "Banking",
    subtitle: "Manage your finances.",
    icon: "🏦",
    levels: {
      easy: [
        { q: "How much do I have in my account?", a: "Account balance." },
        { q: "Can I withdraw some money?", a: "Cash request." },
        { q: "I need to open a new account.", a: "Account creation." },
        { q: "Can I get a receipt?", a: "Proof of transaction." },
        { q: "I need to pay my bill.", a: "Bill payment." },
      ],
      normal: [
        { q: "Can you help me with my loan?", a: "Financial assistance." },
        { q: "I need to transfer money.", a: "Funds transfer." },
        { q: "Can you explain my statement?", a: "Account summary." },
        { q: "I need to close my account.", a: "Account termination." },
        { q: "I need to report a lost card.", a: "Card security." },
      ],
      hard: [
        { q: "I need to dispute a charge.", a: "Financial disagreement." },
        { q: "Can you help me with my investment?", a: "Asset management." },
        { q: "I need to review my credit score.", a: "Financial evaluation." },
        { q: "I need to open a business account.", a: "Corporate banking." },
        { q: "I need to report fraudulent activity.", a: "Security concern." },
      ],
    },
  },
  hotel: {
    id: "hotel",
    title: "Hotel",
    subtitle: "Stay comfortable.",
    icon: "🏨",
    levels: {
      easy: [
        { q: "Where is the reception?", a: "Hotel desk location." },
        { q: "Can I have a room key?", a: "Access to room." },
        { q: "Where is the swimming pool?", a: "Facility location." },
        { q: "Can I check out now?", a: "Leaving hotel." },
        { q: "I need a pillow.", a: "Bedding request." },
      ],
      normal: [
        { q: "Do you have a restaurant?", a: "Food service." },
        { q: "Can I have a late checkout?", a: "Extended stay." },
        { q: "Where is the gym?", a: "Fitness facility." },
        { q: "I need to make a reservation.", a: "Room booking." },
        { q: "Can I have a minibar?", a: "Bar service." },
      ],
      hard: [
        { q: "I need to report a maintenance issue.", a: "Facility problem." },
        { q: "Can I have a VIP room?", a: "Luxury accommodation." },
        { q: "I need to cancel my reservation.", a: "Plan modification." },
        { q: "Can I have a room upgrade?", a: "Better accommodations." },
        { q: "I need to report a security incident.", a: "Safety concern." },
      ],
    },
  },
  airport: {
    id: "airport",
    title: "Airport",
    subtitle: "Travel smoothly.",
    icon: "✈️",
    levels: {
      easy: [
        { q: "Where is the gate?", a: "Boarding location." },
        { q: "Can I have a boarding pass?", a: "Travel document." },
        { q: "Where is the restroom?", a: "Bathroom location." },
        { q: "Can I have a ticket?", a: "Travel document." },
        { q: "Where is the baggage claim?", a: "Bag retrieval location." },
      ],
      normal: [
        { q: "Can I check my flight status?", a: "Travel information." },
        { q: "Where is the security checkpoint?", a: "Safety screening location." },
        { q: "Can I have a seat assignment?", a: "Flight seating." },
        { q: "Where is the lost and found?", a: "Baggage retrieval." },
        { q: "Can I have a visa stamp?", a: "Travel document." },
      ],
      hard: [
        { q: "I need to report a lost passport.", a: "Travel document security." },
        { q: "Can I have a priority boarding pass?", a: "Travel convenience." },
        { q: "I need to cancel my flight.", a: "Travel modification." },
        { q: "Can I have a first-class upgrade?", a: "Travel luxury." },
        { q: "I need to report a security threat.", a: "Safety concern." },
      ],
    },
  },
}
