export interface DailyStats {
  date: string
  activeUsers: number
  newUsers: number
  cardsCompleted: number
  xpEarned: number
}

export interface CategoryStat {
  id: string
  name: string
  users: number
  completionRate: number
  avgScore: number
  popularity: number // 0-100
}

export interface FeedbackItem {
  id: string
  user: string
  message: string
  rating: number
  date: string
  category: string
  aiTag: "bug" | "feature" | "confusion" | "ui_issue"
  status: "new" | "read" | "resolved"
}

export interface AiStat {
  date: string
  queries: number
  errors: number
  avgResponseTime: number // ms
}

export const MOCK_DAILY_STATS: DailyStats[] = Array.from({ length: 14 }).map((_, i) => {
  const date = new Date()
  date.setDate(date.getDate() - (13 - i))
  return {
    date: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    activeUsers: Math.floor(120 + Math.random() * 50 + i * 5),
    newUsers: Math.floor(10 + Math.random() * 15),
    cardsCompleted: Math.floor(1500 + Math.random() * 500 + i * 20),
    xpEarned: Math.floor(5000 + Math.random() * 2000),
  }
})

export const MOCK_CATEGORY_STATS: CategoryStat[] = [
  { id: "travel", name: "Travel", users: 1240, completionRate: 65, avgScore: 8.2, popularity: 95 },
  { id: "food", name: "Food", users: 1150, completionRate: 72, avgScore: 8.8, popularity: 88 },
  { id: "greetings", name: "Greetings", users: 980, completionRate: 90, avgScore: 9.5, popularity: 82 },
  { id: "interview", name: "Interview", users: 850, completionRate: 45, avgScore: 7.1, popularity: 75 },
  { id: "manglish", name: "Manglish", users: 620, completionRate: 88, avgScore: 9.2, popularity: 60 },
  { id: "technology", name: "Technology", users: 540, completionRate: 55, avgScore: 7.8, popularity: 55 },
]

export const MOCK_FEEDBACK: FeedbackItem[] = [
  {
    id: "1",
    user: "Sarah K.",
    message: "The audio for 'Water' sounds a bit robotic.",
    rating: 4,
    date: "2 hours ago",
    category: "Food",
    aiTag: "confusion",
    status: "new",
  },
  {
    id: "2",
    user: "Mike R.",
    message: "Found a typo in the Interview section.",
    rating: 5,
    date: "5 hours ago",
    category: "Interview",
    aiTag: "bug",
    status: "new",
  },
  {
    id: "3",
    user: "Jenny L.",
    message: "Can we have a dark mode toggle? Oh wait, it's already dark!",
    rating: 5,
    date: "1 day ago",
    category: "UI",
    aiTag: "feature",
    status: "read",
  },
  {
    id: "4",
    user: "Ahmad Z.",
    message: "The Manglish section is hilarious! Tambah lagi please.",
    rating: 5,
    date: "2 days ago",
    category: "Manglish",
    aiTag: "feature",
    status: "read",
  },
  {
    id: "5",
    user: "User_992",
    message: "App crashed when I flipped card fast.",
    rating: 2,
    date: "3 days ago",
    category: "System",
    aiTag: "bug",
    status: "resolved",
  },
]

export const MOCK_AI_STATS: AiStat[] = Array.from({ length: 7 }).map((_, i) => {
  const date = new Date()
  date.setDate(date.getDate() - (6 - i))
  return {
    date: date.toLocaleDateString("en-US", { weekday: "short" }),
    queries: Math.floor(50 + Math.random() * 30),
    errors: Math.floor(Math.random() * 3),
    avgResponseTime: Math.floor(800 + Math.random() * 400),
  }
})

export const MOCK_OVERVIEW = {
  totalUsers: 3420,
  activeToday: 452,
  totalCardsViewed: 45210,
  totalXpEarned: 125400,
  avgSessionTime: "14m 32s",
  retentionRate: "68%",
  completionRate: "42%",
}
