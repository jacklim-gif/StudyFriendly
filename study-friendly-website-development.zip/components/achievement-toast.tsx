interface AchievementToastProps {
  title: string
  icon: string
  onClose: () => void
}

export function AchievementToast({ title, icon, onClose }: AchievementToastProps) {
  return (
    <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 animate-fade-in">
      <div className="flex items-center gap-3 px-6 py-4 rounded-2xl bg-gradient-to-r from-[var(--color-primary-blue)] to-[var(--color-secondary-blue)] text-black font-bold shadow-[0_0_40px_rgba(0,242,255,0.6)]">
        <span className="text-3xl">{icon}</span>
        <div>
          <div className="text-xs opacity-70">Achievement Unlocked!</div>
          <div className="text-lg">{title}</div>
        </div>
      </div>
    </div>
  )
}
