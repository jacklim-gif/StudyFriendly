"use client"

import { type BadgeId, BADGES } from "@/lib/achievements"
import { type CategoryId, STUDY_DATA } from "@/lib/data"

interface ProgressDashboardProps {
  onClose: () => void
  stats: {
    xp: number
    level: number
    cardsFlipped: number
    masteredCards: number
    categoriesCompleted: CategoryId[]
    currentStreak: number
    aiHelpCount: number
    unlockedBadges: BadgeId[]
  }
}

export function ProgressDashboard({ onClose, stats }: ProgressDashboardProps) {
  const xpToNextLevel = stats.level * 100
  const xpProgress = (stats.xp / xpToNextLevel) * 100

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[#0a0a0a] border border-[var(--color-primary-blue)]/30 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-[#0a0a0a] border-b border-white/10 p-6 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-[var(--color-primary-blue)]">Your Progress</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors text-2xl leading-none">
            ×
          </button>
        </div>

        <div className="p-6 space-y-8">
          {/* Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[var(--color-glass)] border border-white/10 rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-[var(--color-primary-blue)]">{stats.level}</div>
              <div className="text-sm text-gray-400 mt-1">Level</div>
            </div>
            <div className="bg-[var(--color-glass)] border border-white/10 rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-[var(--color-primary-blue)]">{stats.xp}</div>
              <div className="text-sm text-gray-400 mt-1">Total XP</div>
            </div>
            <div className="bg-[var(--color-glass)] border border-white/10 rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-[var(--color-primary-blue)]">{stats.cardsFlipped}</div>
              <div className="text-sm text-gray-400 mt-1">Cards Flipped</div>
            </div>
            <div className="bg-[var(--color-glass)] border border-white/10 rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-[var(--color-primary-blue)]">{stats.currentStreak}</div>
              <div className="text-sm text-gray-400 mt-1">Day Streak 🔥</div>
            </div>
          </div>

          {/* Level Progress */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-400">Level {stats.level} Progress</span>
              <span className="text-sm text-[var(--color-primary-blue)] font-bold">
                {stats.xp} / {xpToNextLevel} XP
              </span>
            </div>
            <div className="w-full h-3 bg-[#222] rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[var(--color-secondary-blue)] to-[var(--color-primary-blue)] transition-all duration-500 shadow-[0_0_15px_var(--color-primary-blue)]"
                style={{ width: `${xpProgress}%` }}
              />
            </div>
          </div>

          {/* Achievements */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">Achievements</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {Object.values(BADGES).map((badge) => {
                const isUnlocked = stats.unlockedBadges.includes(badge.id)
                return (
                  <div
                    key={badge.id}
                    className={`p-4 rounded-xl border transition-all ${
                      isUnlocked
                        ? "bg-[var(--color-glass)] border-[var(--color-primary-blue)]/50 shadow-[0_0_15px_rgba(0,242,255,0.1)]"
                        : "bg-[#111] border-white/10 opacity-50"
                    }`}
                  >
                    <div className="text-3xl mb-2">{badge.icon}</div>
                    <div className="text-sm font-bold text-white">{badge.title}</div>
                    <div className="text-xs text-gray-400 mt-1">{badge.description}</div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Categories Progress */}
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">Categories Completed</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {stats.categoriesCompleted.map((catId) => {
                const cat = STUDY_DATA[catId]
                return (
                  <div
                    key={catId}
                    className="flex items-center gap-2 p-3 bg-[var(--color-glass)] border border-[var(--color-primary-blue)]/30 rounded-xl"
                  >
                    <span className="text-2xl">{cat.icon}</span>
                    <span className="text-xs font-medium text-white">{cat.title}</span>
                  </div>
                )
              })}
              {stats.categoriesCompleted.length === 0 && (
                <div className="col-span-full text-center text-gray-500 py-8">
                  Complete your first category to see it here!
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
