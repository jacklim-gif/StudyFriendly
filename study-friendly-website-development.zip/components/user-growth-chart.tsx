"use client"

import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface UserGrowthChartProps {
  data: Array<{
    date: string
    users: number
    activeUsers: number
  }>
}

export function UserGrowthChart({ data }: UserGrowthChartProps) {
  return (
    <Card className="bg-[var(--color-card-bg)] border-white/10">
      <CardHeader>
        <CardTitle className="text-white">User Growth</CardTitle>
        <CardDescription className="text-gray-400">Total and active users over time</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="date" stroke="#888" style={{ fontSize: "12px" }} />
            <YAxis stroke="#888" style={{ fontSize: "12px" }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#111",
                border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: "8px",
                color: "#fff",
              }}
            />
            <Line
              type="monotone"
              dataKey="users"
              stroke="var(--color-primary-blue)"
              strokeWidth={2}
              dot={{ fill: "var(--color-primary-blue)", r: 4 }}
              name="Total Users"
            />
            <Line
              type="monotone"
              dataKey="activeUsers"
              stroke="var(--color-secondary-blue)"
              strokeWidth={2}
              dot={{ fill: "var(--color-secondary-blue)", r: 4 }}
              name="Active Users"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
