"use client"

import type React from "react"

import { cn } from "@/lib/utils"
import { TrendingUp, TrendingDown, Smartphone, Monitor, Tablet, Globe } from "lucide-react"
import type { DailyStats, CategoryStat, FeedbackItem, AiStat } from "@/lib/mock-admin-data"

interface StatCardProps {
  title: string
  value: string | number
  change?: string
  trend?: "up" | "down" | "neutral"
  icon: React.ElementType
  color?: string
}

export function StatCard({ title, value, change, trend, icon: Icon, color = "text-white" }: StatCardProps) {
  return (
    <div className="bg-[var(--color-card-bg)] border border-white/10 p-6 rounded-2xl flex items-start justify-between hover:border-white/20 transition-colors">
      <div>
        <p className="text-gray-400 text-sm font-medium mb-1">{title}</p>
        <h3 className="text-3xl font-bold mb-2">{value}</h3>
        {change && (
          <div
            className={cn(
              "flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full w-fit",
              trend === "up"
                ? "bg-green-500/10 text-green-400"
                : trend === "down"
                  ? "bg-red-500/10 text-red-400"
                  : "bg-gray-500/10 text-gray-400",
            )}
          >
            {trend === "up" ? (
              <TrendingUp className="w-3 h-3" />
            ) : trend === "down" ? (
              <TrendingDown className="w-3 h-3" />
            ) : null}
            {change}
          </div>
        )}
      </div>
      <div className={cn("p-3 rounded-xl bg-white/5", color)}>
        <Icon className="w-6 h-6" />
      </div>
    </div>
  )
}

export function GrowthChart({ data }: { data: DailyStats[] }) {
  const maxVal = Math.max(...data.map((d) => d.activeUsers))

  return (
    <div className="h-[200px] w-full flex items-end gap-2 mt-4 px-2">
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
          <div
            className="w-full bg-[var(--color-primary-blue)] opacity-50 hover:opacity-100 transition-all rounded-t-sm relative group-hover:shadow-[0_0_10px_var(--color-primary-blue)]"
            style={{ height: `${(d.activeUsers / maxVal) * 100}%` }}
          >
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-black border border-white/10 px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
              {d.activeUsers} users
            </div>
          </div>
          <span className="text-[10px] text-gray-500 rotate-0 md:rotate-0 truncate w-full text-center">{d.date}</span>
        </div>
      ))}
    </div>
  )
}

export function CategoryChart({ data }: { data: CategoryStat[] }) {
  return (
    <div className="space-y-4 mt-4">
      {data.slice(0, 5).map((cat) => (
        <div key={cat.id} className="space-y-1">
          <div className="flex justify-between text-sm">
            <span className="font-medium text-gray-300">{cat.name}</span>
            <span className="text-gray-500">{cat.completionRate}% complete</span>
          </div>
          <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[var(--color-primary-blue)] to-purple-500 rounded-full"
              style={{ width: `${cat.popularity}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  )
}

export function ActivityHeatmap() {
  // Mock heatmap data: 7 days x 24 hours
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
  const hours = [0, 4, 8, 12, 16, 20]

  return (
    <div className="mt-4">
      <div className="flex gap-1 mb-2">
        <div className="w-8"></div>
        {Array.from({ length: 24 }).map((_, h) => (
          <div key={h} className="flex-1 text-[9px] text-gray-600 text-center">
            {h % 4 === 0 ? h : ""}
          </div>
        ))}
      </div>
      <div className="flex flex-col gap-1">
        {days.map((day) => (
          <div key={day} className="flex gap-1 items-center">
            <span className="w-8 text-[10px] text-gray-500">{day}</span>
            {Array.from({ length: 24 }).map((_, h) => {
              // Generate pseudo-random intensity based on day/hour logic
              // Weekends (5,6) and evenings (18-22) are busier
              const isWeekend = day === "Sat" || day === "Sun"
              const isEvening = h >= 18 && h <= 22
              const isWork = h >= 9 && h <= 17
              let intensity = 0.1
              if (isWeekend) intensity += 0.3
              if (isEvening) intensity += 0.5
              if (isWork && !isWeekend) intensity += 0.2
              intensity = Math.min(Math.random() * 0.2 + intensity, 1)

              return (
                <div
                  key={h}
                  className="flex-1 aspect-square rounded-[1px] hover:scale-125 transition-transform cursor-pointer relative group"
                  style={{
                    backgroundColor: `rgba(0, 242, 255, ${intensity})`,
                    opacity: Math.max(0.1, intensity),
                  }}
                >
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 bg-black border border-white/10 text-[10px] px-2 py-1 rounded hidden group-hover:block z-20 whitespace-nowrap">
                    {Math.floor(intensity * 100)} users
                  </div>
                </div>
              )
            })}
          </div>
        ))}
      </div>
      <div className="flex justify-between items-center mt-3 text-[10px] text-gray-500 px-2">
        <span>Less Active</span>
        <div className="flex gap-1">
          <div className="w-3 h-3 bg-[var(--color-primary-blue)] opacity-10 rounded"></div>
          <div className="w-3 h-3 bg-[var(--color-primary-blue)] opacity-40 rounded"></div>
          <div className="w-3 h-3 bg-[var(--color-primary-blue)] opacity-70 rounded"></div>
          <div className="w-3 h-3 bg-[var(--color-primary-blue)] opacity-100 rounded"></div>
        </div>
        <span>More Active</span>
      </div>
    </div>
  )
}

export function FeedbackList({ items }: { items: FeedbackItem[] }) {
  return (
    <div className="space-y-4 mt-4">
      {items.map((item) => (
        <div
          key={item.id}
          className="flex gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
        >
          <div
            className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center shrink-0 font-bold text-sm",
              item.rating >= 4
                ? "bg-green-500/20 text-green-400"
                : item.rating >= 3
                  ? "bg-yellow-500/20 text-yellow-400"
                  : "bg-red-500/20 text-red-400",
            )}
          >
            {item.rating}★
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-start mb-1">
              <h4 className="font-bold text-sm text-white truncate">{item.user}</h4>
              <span className="text-[10px] text-gray-500">{item.date}</span>
            </div>
            <p className="text-xs text-gray-300 line-clamp-2 mb-2">{item.message}</p>
            <div className="flex gap-2">
              <span
                className={cn(
                  "text-[10px] px-1.5 py-0.5 rounded capitalize border",
                  item.aiTag === "bug"
                    ? "border-red-500/30 text-red-400 bg-red-500/10"
                    : item.aiTag === "feature"
                      ? "border-blue-500/30 text-blue-400 bg-blue-500/10"
                      : "border-gray-500/30 text-gray-400 bg-gray-500/10",
                )}
              >
                {item.aiTag}
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded border border-white/10 text-gray-500 bg-black">
                {item.category}
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

export function AiStatsWidget({ stats }: { stats: AiStat[] }) {
  return (
    <div className="mt-4 space-y-4">
      <div className="flex justify-between items-end gap-2 h-32 pb-2 border-b border-white/10">
        {stats.map((stat, i) => (
          <div key={i} className="flex-1 flex flex-col justify-end gap-1 group">
            <div
              className="w-full bg-purple-500/50 hover:bg-purple-500 rounded-t transition-colors relative"
              style={{ height: `${(stat.queries / 100) * 100}%` }}
            >
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] opacity-0 group-hover:opacity-100 bg-black px-1 rounded">
                {stat.queries}
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="bg-white/5 p-2 rounded-lg">
          <div className="text-xs text-gray-400">Queries</div>
          <div className="font-bold text-purple-400">{stats.reduce((a, b) => a + b.queries, 0)}</div>
        </div>
        <div className="bg-white/5 p-2 rounded-lg">
          <div className="text-xs text-gray-400">Avg Time</div>
          <div className="font-bold text-blue-400">1.2s</div>
        </div>
        <div className="bg-white/5 p-2 rounded-lg">
          <div className="text-xs text-gray-400">Errors</div>
          <div className="font-bold text-red-400">{stats.reduce((a, b) => a + b.errors, 0)}</div>
        </div>
      </div>
    </div>
  )
}

export function DeviceStats() {
  return (
    <div className="mt-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <Smartphone className="w-4 h-4 text-blue-400" /> Mobile
        </div>
        <div className="flex items-center gap-2">
          <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 w-[65%]" />
          </div>
          <span className="text-xs text-gray-500 w-8 text-right">65%</span>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <Monitor className="w-4 h-4 text-green-400" /> Desktop
        </div>
        <div className="flex items-center gap-2">
          <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-green-500 w-[25%]" />
          </div>
          <span className="text-xs text-gray-500 w-8 text-right">25%</span>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <Tablet className="w-4 h-4 text-purple-400" /> Tablet
        </div>
        <div className="flex items-center gap-2">
          <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-purple-500 w-[10%]" />
          </div>
          <span className="text-xs text-gray-500 w-8 text-right">10%</span>
        </div>
      </div>
    </div>
  )
}

export function RegionStats() {
  const regions = [
    { name: "Malaysia", count: 45, color: "bg-yellow-500" },
    { name: "Singapore", count: 20, color: "bg-red-500" },
    { name: "Indonesia", count: 15, color: "bg-white" },
    { name: "Other", count: 20, color: "bg-gray-500" },
  ]

  return (
    <div className="mt-4 flex gap-4 items-center">
      <div className="relative w-24 h-24 rounded-full border-4 border-white/10 shrink-0 flex items-center justify-center">
        <Globe className="w-8 h-8 text-gray-600" />
        {/* Simplified pie chart visual */}
        <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90">
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="transparent"
            stroke="var(--color-primary-blue)"
            strokeWidth="10"
            strokeDasharray="150 251"
          />
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="transparent"
            stroke="purple"
            strokeWidth="10"
            strokeDasharray="60 251"
            strokeDashoffset="-150"
          />
        </svg>
      </div>
      <div className="flex-1 space-y-2">
        {regions.map((r) => (
          <div key={r.name} className="flex justify-between text-xs">
            <span className="flex items-center gap-2 text-gray-300">
              <span className={cn("w-2 h-2 rounded-full", r.color)} />
              {r.name}
            </span>
            <span className="text-gray-500">{r.count}%</span>
          </div>
        ))}
      </div>
    </div>
  )
}
