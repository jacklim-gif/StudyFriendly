"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, Users, BookOpen, Layers, MessageSquare, Bot, Settings, LogOut } from "lucide-react"
import { cn } from "@/lib/utils"

const NAV_ITEMS = [
  { name: "Overview", href: "/admin", icon: LayoutDashboard },
  { name: "User Analytics", href: "/admin/users", icon: Users },
  { name: "Learning Stats", href: "/admin/learning", icon: BookOpen },
  { name: "Categories", href: "/admin/categories", icon: Layers },
  { name: "Feedback", href: "/admin/feedback", icon: MessageSquare },
  { name: "AI Insights", href: "/admin/ai", icon: Bot },
  { name: "Settings", href: "/admin/settings", icon: Settings },
]

export function AdminSidebar() {
  const pathname = usePathname()

  return (
    <div className="w-64 h-screen bg-black border-r border-white/10 flex flex-col fixed left-0 top-0 z-50">
      <div className="p-6 border-b border-white/10">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <span className="text-[var(--color-primary-blue)]">Study</span>Friendly
          <span className="text-xs bg-white/10 px-2 py-0.5 rounded text-gray-400">ADMIN</span>
        </h1>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-[var(--color-primary-blue)]/10 text-[var(--color-primary-blue)]"
                  : "text-gray-400 hover:text-white hover:bg-white/5",
              )}
            >
              <item.icon className="w-4 h-4" />
              {item.name}
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t border-white/10">
        <Link
          href="/"
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-gray-400 hover:text-white hover:bg-white/5 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Back to App
        </Link>
      </div>
    </div>
  )
}
