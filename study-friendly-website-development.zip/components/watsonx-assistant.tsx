"use client"

import { useEffect, useState } from "react"

// 1. Define types for the NEW watsonx Orchestrate library
declare global {
  interface Window {
    wxOConfiguration?: {
      orchestrationID: string
      hostURL: string
      rootElementID: string
      deploymentPlatform: string
      crn?: string
      chatOptions: {
        agentId: string
        agentEnvironmentId: string
      }
    }
    wxoLoader?: {
      init: () => void
    }
  }
}

export function WatsonxAssistant() {
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)

    // 2. CONFIGURATION: I have filled this with YOUR specific data
const config = {
  // Your Orchestration ID
   orchestrationID: "6080bfb9e8a94c7f9ba974402218c2a3_10a467b3-7586-488d-8cbd-e1376f179a00",
  hostURL: "https://ca-tor.watson-orchestrate.cloud.ibm.com",
  rootElementID: "root",
  deploymentPlatform: "ibmcloud",
  crn: "crn:v1:bluemix:public:watsonx-orchestrate:ca-tor:a/6080bfb9e8a94c7f9ba974402218c2a3:10a467b3-7586-488d-8cbd-e1376f179a00::",
  chatOptions: {
    agentId: "3749e49d-b3b3-47ad-ae75-a511bbac26a5",
    agentEnvironmentId: "52cdcbab-c77f-45e7-96e0-d50bbefba6c4",
  },
  auth: {
    token: "Bearer eyJraWQiOiIyMDE5MDcyNCIsImFsZyI6IlJTMjU2In0.eyJpYW1faWQiOiJJQk1pZC02OTIwMDE5WUhKIiwiaWQiOiJJQk1pZC02OTIwMDE5WUhKIiwicmVhbG1pZCI6IklCTWlkIiwic2Vzc2lvbl9pZCI6IkMtZGRjY2M2M2UtMTNmOS00NzVlLWE1MGUtMjZjOGYyYzVkM2I2Iiwic2Vzc2lvbl9leHBfbWF4IjoxNzYzOTUxOTIxLCJzZXNzaW9uX2V4cF9uZXh0IjoxNzYzODk0ODQwLCJqdGkiOiJjMGZmOTU3OS02Njg2LTQ0NDUtYTIxYy0yYTI1NTNhNWVlOWQiLCJpZGVudGlmaWVyIjoiNjkyMDAxOVlISiIsImdpdmVuX25hbWUiOiJKYWNrIiwiZmFtaWx5X25hbWUiOiJMaW0iLCJuYW1lIjoiSmFjayBMaW0iLCJlbWFpbCI6ImxpbWphY2s1NzcyQGdtYWlsLmNvbSIsInN1YiI6ImxpbWphY2s1NzcyQGdtYWlsLmNvbSIsImF1dGhuIjp7InN1YiI6ImxpbWphY2s1NzcyQGdtYWlsLmNvbSIsImlhbV9pZCI6IklCTWlkLTY5MjAwMTlZSEoiLCJuYW1lIjoiSmFjayBMaW0iLCJnaXZlbl9uYW1lIjoiSmFjayIsImZhbWlseV9uYW1lIjoiTGltIiwiZW1haWwiOiJsaW1qYWNrNTc3MkBnbWFpbC5jb20ifSwiYWNjb3VudCI6eyJ2YWxpZCI6dHJ1ZSwiYnNzIjoiNjA4MGJmYjllOGE5NGM3ZjliYTk3NDQwMjIxOGMyYTMiLCJpbXNfdXNlcl9pZCI6IjE0NzYwODgwIiwiaW1zIjoiMzAwMTYxOCJ9LCJpYXQiOjE3NjM4ODc2MzcsImV4cCI6MTc2Mzg4ODgzNywiaXNzIjoiaHR0cHM6Ly9pYW0uY2xvdWQuaWJtLmNvbS9pZGVudGl0eSIsImdyYW50X3R5cGUiOiJ1cm46aWJtOnBhcmFtczpvYXV0aDpncmFudC10eXBlOnBhc3Njb2RlIiwic2NvcGUiOiJpYm0gb3BlbmlkIiwiY2xpZW50X2lkIjoiYngiLCJhY3IiOjEsImFtciI6WyJwd2QiXX0.Fjwit-bA9oU50Hfdd7ikBb8TbqOb_meqT76JFUSIoUHMgHITLckSkTLkZwy0KaNob6aHogfYA_Bl76qQjKn1mn7d2STn8XubgHzLmkTgQG1OgvMfJ5ElwUMauWKNt5dPgvjQ8_I2Nrawfn5EuqzpzCJhqJvKQk9gmyYd7WZILP5x8U0JD-uSe0xqlvE9gCAg3I73HiA49k_2CJeIAaT_gHT5WCvESJhvtqZvSlbAePGEYEz2KYIk1YyemGLPwhyoQvyWtV540kyiPi-kAWXkeMZAIlNlZtHP1PZRO"
  }
};

    // Attach config to window
    window.wxOConfiguration = config

    // 3. LOAD THE SCRIPT
    const script = document.createElement("script")
    script.src = `${config.hostURL}/wxochat/wxoLoader.js?embed=true`
    script.async = true
    
    script.onload = () => {
      if (window.wxoLoader) {
        window.wxoLoader.init()
        console.log("✅ StudyFriendly Agent Connected")
      }
    }

    script.onerror = () => {
      console.error("❌ Failed to load Watsonx Chat. Check if AdBlock is on.")
    }

    document.head.appendChild(script)

    // Cleanup
    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script)
      }
    }
  }, [])

  if (!isMounted) return null

  // The IBM script automatically injects the UI.
  return <div id="wxo-chat-container" />
}
