"use client"

import { useState, useRef, useEffect } from "react"
import type { Question } from "@/lib/data"

interface FlashcardProps {
  data: Question
  onNext: () => void
  onMastered: () => void
  onNeedsPractice: () => void
  onFlip: () => void
}

export function Flashcard({ data, onNext, onMastered, onNeedsPractice, onFlip }: FlashcardProps) {
  const [isFlipped, setIsFlipped] = useState(false)
  const [displayData, setDisplayData] = useState(data)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  // Initialize audio
  useEffect(() => {
    audioRef.current = new Audio("https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3")
    audioRef.current.volume = 0.3
  }, [])

  // When data prop changes, update display data after a delay if currently flipped
  // This prevents the text from changing while the user is looking at the back of the card
  useEffect(() => {
    if (isFlipped) {
      setIsFlipped(false)
      setTimeout(() => {
        setDisplayData(data)
      }, 300) // Wait for half the flip animation
    } else {
      setDisplayData(data)
    }
  }, [data])

  const handleFlip = () => {
    const wasFlipped = isFlipped
    setIsFlipped(!isFlipped)
    if (!wasFlipped && audioRef.current) {
      audioRef.current.currentTime = 0
      audioRef.current.play().catch((e) => console.log("Audio play failed", e))
      onFlip()
    }
  }

  const handleMastered = () => {
    onMastered()
    onNext()
  }

  const handleNeedsPractice = () => {
    onNeedsPractice()
    onNext()
  }

  return (
    <div className="flex flex-col items-center w-full max-w-2xl mx-auto">
      {/* 3D Scene */}
      <div className="perspective-1000 w-full h-[300px] md:h-[350px] mb-6 cursor-pointer group" onClick={handleFlip}>
        <div
          className={`relative w-full h-full transition-transform duration-700 cubic-bezier(0.4, 0.2, 0.2, 1) transform-style-3d ${isFlipped ? "rotate-y-180" : ""}`}
        >
          {/* Front Face */}
          <div className="absolute inset-0 w-full h-full backface-hidden rounded-2xl p-8 flex flex-col items-center justify-center text-center bg-gradient-to-br from-[#1a1a1a] to-[#0a0a0a] border border-white/10 border-b-4 border-b-[var(--color-secondary-blue)] shadow-2xl group-hover:border-[var(--color-primary-blue)]/30 transition-colors">
            <div className="text-sm uppercase tracking-[0.2em] text-gray-400 mb-6">Question</div>
            <div className="text-2xl md:text-4xl font-medium leading-tight text-balance">{displayData.q}</div>
            <div className="mt-6 text-xs text-[var(--color-primary-blue)] opacity-70 animate-pulse">
              Click to show answer
            </div>
          </div>

          {/* Back Face */}
          <div className="absolute inset-0 w-full h-full backface-hidden rounded-2xl p-8 flex flex-col items-center justify-center text-center bg-gradient-to-br from-[#0f172a] to-black border border-white/10 border-b-4 border-b-[var(--color-primary-blue)] rotate-y-180 shadow-[0_0_30px_rgba(0,242,255,0.1)]">
            <div className="text-sm uppercase tracking-[0.2em] text-gray-400 mb-6">Answer</div>
            <div className="text-xl md:text-3xl font-medium leading-relaxed text-balance text-[var(--color-primary-blue)]">
              {displayData.a}
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-md">
        <button
          onClick={handleNeedsPractice}
          className="w-full sm:w-auto px-6 py-3 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 font-medium hover:bg-red-500/20 hover:border-red-500/50 transition-all hover:scale-105 active:scale-95"
        >
          Need Practice
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation()
            onNext()
          }}
          className="w-full sm:w-auto px-6 py-3 rounded-full bg-[var(--color-glass)] border border-white/10 text-white font-medium hover:bg-white/10 transition-all hover:scale-105 active:scale-95"
        >
          Skip →
        </button>

        <button
          onClick={handleMastered}
          className="w-full sm:w-auto px-6 py-3 rounded-full bg-green-500/10 border border-green-500/30 text-green-400 font-medium hover:bg-green-500/20 hover:border-green-500/50 transition-all hover:scale-105 active:scale-95"
        >
          Got It! ✓
        </button>
      </div>
    </div>
  )
}
