"use client"

import Link from "next/link"
import { Lock } from "lucide-react"

interface HeaderProps {
  progress: number
  xp: number
  level: number
  onOpenDashboard: () => void
}

export function Header({ progress, xp, level, onOpenDashboard }: HeaderProps) {
  const xpToNextLevel = level * 100
  const xpProgress = (xp / xpToNextLevel) * 100

  return (
    <header className="flex items-center justify-between px-4 md:px-10 py-4 border-b border-[rgba(0,242,255,0.1)] bg-gradient-to-r from-black/90 to-transparent sticky top-0 z-50 backdrop-blur-sm">
      <div className="flex items-center gap-4">
        <div className="text-xl md:text-2xl font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-[var(--color-primary-blue)] to-[var(--color-secondary-blue)]">
          StudyFriendly
        </div>

        {/* Level Badge */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--color-glass)] border border-[var(--color-primary-blue)]/30">
          <span className="text-xs text-gray-400">Level</span>
          <span className="text-sm font-bold text-[var(--color-primary-blue)]">{level}</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Link
          href="/admin"
          className="p-2 rounded-full bg-[var(--color-glass)] border border-[var(--color-primary-blue)]/30 text-gray-400 hover:text-[var(--color-primary-blue)] hover:bg-[var(--color-primary-blue)]/10 transition-all"
          title="Admin Panel"
        >
          <Lock className="w-4 h-4" />
        </Link>

        <button
          onClick={onOpenDashboard}
          className="px-3 py-1.5 rounded-full bg-[var(--color-glass)] border border-[var(--color-primary-blue)]/30 text-xs font-medium text-[var(--color-primary-blue)] hover:bg-[var(--color-primary-blue)]/10 transition-all"
        >
          Dashboard
        </button>

        {/* XP Display */}
        <div className="hidden md:flex flex-col items-end gap-1">
          <div className="text-xs text-gray-400">
            {xp} / {xpToNextLevel} XP
          </div>
          <div className="w-32 h-1.5 bg-[#222] rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[var(--color-secondary-blue)] to-[var(--color-primary-blue)] transition-all duration-500 ease-out"
              style={{ width: `${xpProgress}%` }}
            />
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-24 md:w-40 h-2 bg-[#222] rounded-full overflow-hidden">
          <div
            className="h-full bg-[var(--color-primary-blue)] transition-all duration-500 ease-out shadow-[0_0_10px_var(--color-primary-blue)]"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </header>
  )
}
