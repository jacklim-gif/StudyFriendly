"use client"

import { useState, useRef, useEffect } from "react"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
}

export function SupportChat() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hi! I'm your StudyFriendly guide. Type any question below!",
    },
  ])
  const [input, setInput] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const faqAnswers: Record<string, string> = {
    "how to use": "Just pick a category → flip cards → answer correctly to earn XP!\n\nCorrect = +15 XP (mastered) or +5 XP (practice)\nWrong = try again later\nMaster all cards to level up!",
    
    "how does it work": "StudyFriendly uses a simple gamified system:\n• Flip card → see answer → mark if you knew it\n• Earn XP → level up every 100 XP\n• Cards move from Easy → Normal → Hard\n• All progress saved automatically",

    "legit": "Yes lah, 100% legit! No ads, no paywall, no tracking. Pure learning app made with love in Malaysia. Your progress stays forever (localStorage)",

    "xp": "You earn XP like this:\n+15 XP → when you master a card (you knew it well)\n+5 XP → when you practice (you got it right but not confident)\nEvery 100 XP = 1 level up!",

    "level up": "You level up every 100 XP!\nLevel 1 → 100 XP\nLevel 2 → 200 XP total\nLevel 3 → 300 XP total\n...and so on. Keep studying to become a language master!",

    "manglish": "Yes! We have a full Malaysian Manglish category with real phrases like:\n• 'Can lah' → 'It's possible'\n• 'Shiok' → 'Feels great!'\n• 'Lah so stressful' → 'I'm so stressed!'\nPerfect for locals and learners!",

    "save": "Your progress is saved automatically in your browser (localStorage). Even if you close the tab or restart phone, your XP and mastered cards stay forever!",

    "clear": "Want to reset? Just type 'reset all' and I'll clear everything (careful!)",

    "reset all": "Progress cleared! You're starting fresh. Good luck on your learning journey!",
    
    "hello": "Hello! Ready to study?",
    "hi": "Hi lah! How can I help you today?",
    "thanks": "You're welcome! Keep studying — you're doing great!",
    "thank you": "Anytime! Happy learning!",
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const userMsg = input.toLowerCase().trim()
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
    }

    setMessages(prev => [...prev, userMessage])
    setInput("")

    // Special: reset all data
    if (userMsg === "reset all") {
      localStorage.clear()
      setTimeout(() => {
        setMessages(prev => [
          ...prev,
          {
            id: (Date.now() + 1).toString(),
            role: "assistant",
            content: "All progress cleared! Refresh the page to start fresh.",
          },
        ])
      }, 600)
      return
    }

    // Find matching answer
    let reply = "Sorry, I don't understand that yet. Try typing 'how to use' or 'xp'!"

    for (const [key, answer] of Object.entries(faqAnswers)) {
      if (userMsg.includes(key)) {
        reply = answer
        break
      }
    }

    // Send reply after a tiny delay (feels natural)
    setTimeout(() => {
      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: reply,
        },
      ])
    }, 400)
  }

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 left-6 z-50 flex items-center gap-2 px-5 py-3.5 rounded-full bg-[var(--color-primary-blue)] text-black font-bold shadow-[0_0_30px_rgba(0,242,255,0.4)] hover:scale-110 active:scale-95 transition-all"
      >
        AI Guide
        {isOpen ? "×" : "?"}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-20 left-6 z-50 w-[360px] h-[520px] bg-[#0a0a0a] border border-[var(--color-primary-blue)] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
          <div className="p-4 bg-gradient-to-r from-[#111] to-[#1a1a1a] border-b border-white/10 flex justify-between items-center">
            <h3 className="font-bold text-[var(--color-primary-blue)]">StudyFriendly Guide</h3>
            <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white text-2xl">×</button>
          </div>

          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {messages.map((m) => (
              <div key={m.id} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                <div
                  className={cn(
                    "max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
                    m.role === "user"
                      ? "bg-[var(--color-primary-blue)] text-black font-medium rounded-br-none"
                      : "bg-[#222] text-gray-100 border border-white/8 rounded-bl-none whitespace-pre-line"
                  )}
                >
                  {m.content}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSubmit} className="p-4 bg-[#111] border-t border-white/10">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything... (e.g. 'how to use')"
              className="w-full bg-[#222] text-white rounded-full px-5 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-primary-blue)] placeholder:text-gray-500"
              autoFocus
            />
          </form>
        </div>
      )}
    </>
  )
}
