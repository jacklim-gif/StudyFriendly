"use client"

import Link from "next/link"
import { AnalyticsStatCard } from "@/components/analytics-stat-card"
import { UserGrowthChart } from "@/components/user-growth-chart"

// Mock data for the chart
const growthData = [
  { date: "Mon", users: 120, activeUsers: 85 },
  { date: "Tue", users: 132, activeUsers: 90 },
  { date: "Wed", users: 145, activeUsers: 105 },
  { date: "Thu", users: 160, activeUsers: 115 },
  { date: "Fri", users: 178, activeUsers: 125 },
  { date: "Sat", users: 195, activeUsers: 140 },
  { date: "Sun", users: 210, activeUsers: 155 },
]

export default function AnalyticsPage() {
  return (
    <div className="min-h-screen bg-[#050505] text-white p-6 md:p-8 animate-fade-in">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[var(--color-primary-blue)] to-[var(--color-secondary-blue)]">
              User Analytics
            </h1>
            <p className="text-gray-400 mt-1">Overview of user growth and activity</p>
          </div>
          <Link
            href="/"
            className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 hover:border-[var(--color-primary-blue)]/50 transition-all text-sm font-medium"
          >
            ← Back to App
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          <AnalyticsStatCard title="Total Users" value="12,345" icon="👥" trend={{ value: 12, isPositive: true }} />
          <AnalyticsStatCard title="Active Today" value="1,234" icon="⚡" trend={{ value: 5, isPositive: true }} />
          <AnalyticsStatCard title="Active This Week" value="5,678" icon="📅" trend={{ value: 8, isPositive: true }} />
          <AnalyticsStatCard title="New Users Today" value="156" icon="🆕" trend={{ value: 2, isPositive: false }} />
          <AnalyticsStatCard title="Returning Users" value="89%" icon="🔄" trend={{ value: 1.5, isPositive: true }} />
        </div>

        {/* Main Chart Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <UserGrowthChart data={growthData} />
          </div>

          {/* Side Panel / Additional Insights */}
          <div className="bg-[var(--color-card-bg)] border border-white/10 rounded-xl p-6">
            <h3 className="text-lg font-bold text-white mb-4">Quick Insights</h3>
            <div className="space-y-4">
              <div className="p-3 bg-white/5 rounded-lg border border-white/5">
                <div className="text-sm text-gray-400 mb-1">Peak Activity Time</div>
                <div className="font-semibold text-[var(--color-primary-blue)]">2:00 PM - 4:00 PM</div>
              </div>
              <div className="p-3 bg-white/5 rounded-lg border border-white/5">
                <div className="text-sm text-gray-400 mb-1">Top Category</div>
                <div className="font-semibold text-[var(--color-primary-blue)]">Computer Science</div>
              </div>
              <div className="p-3 bg-white/5 rounded-lg border border-white/5">
                <div className="text-sm text-gray-400 mb-1">Average Session</div>
                <div className="font-semibold text-[var(--color-primary-blue)]">24 minutes</div>
              </div>
              <div className="p-3 bg-white/5 rounded-lg border border-white/5">
                <div className="text-sm text-gray-400 mb-1">Conversion Rate</div>
                <div className="font-semibold text-[var(--color-primary-blue)]">4.2%</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
