"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Flashcard } from "@/components/flashcard"
import { STUDY_DATA, type CategoryId, type Level } from "@/lib/data"
import { cn } from "@/lib/utils"
import { SupportChat } from "@/components/support-chat"
import { ProgressDashboard } from "@/components/progress-dashboard"
import { AchievementToast } from "@/components/achievement-toast"
import { BADGES, type BadgeId } from "@/lib/achievements"

export default function Home() {
  // Game State
  const [activeCategory, setActiveCategory] = useState<CategoryId | null>(null)
  const [activeLevel, setActiveLevel] = useState<Level>("easy")
  const [cardIndex, setCardIndex] = useState(0)

  const [hasAwardedXP, setHasAwardedXP] = useState(false)

  const [xp, setXp] = useState(0)
  const [level, setLevel] = useState(1)
  const [masteredCards, setMasteredCards] = useState(0)
  const [cardsFlipped, setCardsFlipped] = useState(0)
  const [categoriesCompleted, setCategoriesCompleted] = useState<CategoryId[]>([])
  const [unlockedBadges, setUnlockedBadges] = useState<BadgeId[]>([])
  const [aiHelpCount, setAiHelpCount] = useState(0)
  const [currentStreak, setCurrentStreak] = useState(0)
  const [lastLoginDate, setLastLoginDate] = useState<string>("")

  const [showDashboard, setShowDashboard] = useState(false)
  const [achievementToShow, setAchievementToShow] = useState<{ title: string; icon: string } | null>(null)

  useEffect(() => {
    const savedXP = localStorage.getItem("studyfriendly_xp")
    const savedLevel = localStorage.getItem("studyfriendly_level")
    const savedMastered = localStorage.getItem("studyfriendly_mastered")
    const savedFlipped = localStorage.getItem("studyfriendly_flipped")
    const savedCategories = localStorage.getItem("studyfriendly_categories")
    const savedBadges = localStorage.getItem("studyfriendly_badges")
    const savedAiHelp = localStorage.getItem("studyfriendly_ai_help")
    const savedStreak = localStorage.getItem("studyfriendly_streak")
    const savedLastLogin = localStorage.getItem("studyfriendly_last_login")

    if (savedXP) setXp(Number.parseInt(savedXP))
    if (savedLevel) setLevel(Number.parseInt(savedLevel))
    if (savedMastered) setMasteredCards(Number.parseInt(savedMastered))
    if (savedFlipped) setCardsFlipped(Number.parseInt(savedFlipped))
    if (savedCategories) setCategoriesCompleted(JSON.parse(savedCategories))
    if (savedBadges) setUnlockedBadges(JSON.parse(savedBadges))
    if (savedAiHelp) setAiHelpCount(Number.parseInt(savedAiHelp))
    if (savedStreak) setCurrentStreak(Number.parseInt(savedStreak))
    if (savedLastLogin) setLastLoginDate(savedLastLogin)

    checkDailyLogin(savedLastLogin, savedStreak ? Number.parseInt(savedStreak) : 0)
  }, [])

  const checkDailyLogin = (lastLogin: string | null, streak: number) => {
    const today = new Date().toDateString()
    const yesterday = new Date(Date.now() - 86400000).toDateString()

    if (lastLogin !== today) {
      setXp((prev) => prev + 1)

      if (lastLogin === yesterday) {
        const newStreak = streak + 1
        setCurrentStreak(newStreak)

        if (newStreak === 7) {
          setXp((prev) => prev + 10)
          showAchievementNotification("🔥 7 Day Streak!", "🔥")
          unlockBadge("daily-streak-7")
        }
      } else if (lastLogin) {
        setCurrentStreak(1)
      } else {
        setCurrentStreak(1)
      }

      setLastLoginDate(today)
    }
  }

  useEffect(() => {
    localStorage.setItem("studyfriendly_xp", xp.toString())
    localStorage.setItem("studyfriendly_level", level.toString())
    localStorage.setItem("studyfriendly_mastered", masteredCards.toString())
    localStorage.setItem("studyfriendly_flipped", cardsFlipped.toString())
    localStorage.setItem("studyfriendly_categories", JSON.stringify(categoriesCompleted))
    localStorage.setItem("studyfriendly_badges", JSON.stringify(unlockedBadges))
    localStorage.setItem("studyfriendly_ai_help", aiHelpCount.toString())
    localStorage.setItem("studyfriendly_streak", currentStreak.toString())
    localStorage.setItem("studyfriendly_last_login", lastLoginDate)
  }, [
    xp,
    level,
    masteredCards,
    cardsFlipped,
    categoriesCompleted,
    unlockedBadges,
    aiHelpCount,
    currentStreak,
    lastLoginDate,
  ])

  const categoryData = activeCategory ? STUDY_DATA[activeCategory] : null
  const currentQuestions = categoryData ? categoryData.levels[activeLevel] : []
  const currentCard = currentQuestions[cardIndex % currentQuestions.length]

  const totalQuestions = currentQuestions.length || 1
  const progress = activeCategory ? (((cardIndex % totalQuestions) + 1) / totalQuestions) * 100 : 0

  useEffect(() => {
    const xpToNextLevel = level * 100
    if (xp >= xpToNextLevel) {
      const newLevel = level + 1
      setLevel(newLevel)
      showAchievementNotification(`Level ${newLevel} Unlocked!`, "⭐")

      if (newLevel === 5) unlockBadge("level-5")
      if (newLevel === 10) unlockBadge("level-10")
      if (newLevel === 20) unlockBadge("level-20")
    }
  }, [xp, level])

  const unlockBadge = (badgeId: BadgeId) => {
    if (!unlockedBadges.includes(badgeId)) {
      setUnlockedBadges((prev) => [...prev, badgeId])
      const badge = BADGES[badgeId]
      showAchievementNotification(badge.title, badge.icon)
    }
  }

  const showAchievementNotification = (title: string, icon: string) => {
    setAchievementToShow({ title, icon })
    setTimeout(() => setAchievementToShow(null), 3000)
  }

  useEffect(() => {
    if (cardsFlipped >= 50) unlockBadge("flashcard-master")
    if (categoriesCompleted.length >= 5) unlockBadge("category-explorer")
    if (categoriesCompleted.includes("grammar")) unlockBadge("grammar-warrior")
    if (aiHelpCount >= 10) unlockBadge("ai-friend")
  }, [cardsFlipped, categoriesCompleted, aiHelpCount])

  const handleCategorySelect = (id: CategoryId) => {
    setActiveCategory(id)
    setActiveLevel("easy")
    setCardIndex(0)
    setHasAwardedXP(false)
  }

  const handleBack = () => {
    setActiveCategory(null)
    setCardIndex(0)
    setHasAwardedXP(false)
  }

  const handleCardFlip = () => {
    if (!hasAwardedXP) {
      setXp((prev) => prev + 2)
      setCardsFlipped((prev) => prev + 1)
      setHasAwardedXP(true)
    }
  }

  const handleNextCard = () => {
    if (cardIndex + 1 >= currentQuestions.length && activeCategory) {
      if (!categoriesCompleted.includes(activeCategory)) {
        setCategoriesCompleted((prev) => [...prev, activeCategory])
        setXp((prev) => prev + 5)
        showAchievementNotification(`${STUDY_DATA[activeCategory].title} Completed!`, STUDY_DATA[activeCategory].icon)

        if (activeLevel === "hard") {
          unlockBadge("super-hard-learner")
        }
      }
    }

    setCardIndex((prev) => prev + 1)
    setHasAwardedXP(false)
  }

  const handleLevelChange = (level: Level) => {
    setActiveLevel(level)
    setCardIndex(0)
    setHasAwardedXP(false)
  }

  const handleMastered = () => {
    if (!hasAwardedXP) {
      setXp((prev) => prev + 15)
      setMasteredCards((prev) => prev + 1)
      setHasAwardedXP(true)
    }
  }

  const handleNeedsPractice = () => {
    if (!hasAwardedXP) {
      setXp((prev) => prev + 5)
      setHasAwardedXP(true)
    }
  }

  const handleAiHelp = () => {
    setXp((prev) => prev + 1)
    setAiHelpCount((prev) => prev + 1)
  }

  const isDifficultyUnlocked = (difficulty: Level): boolean => {
    if (difficulty === "easy") return true
    if (difficulty === "normal") return level >= 4
    if (difficulty === "hard") return level >= 7
    return false
  }

  return (
    <>
      <Header progress={progress} xp={xp} level={level} onOpenDashboard={() => setShowDashboard(true)} />

      <SupportChat onAiHelp={handleAiHelp} />

      {showDashboard && (
        <ProgressDashboard
          onClose={() => setShowDashboard(false)}
          stats={{
            xp,
            level,
            cardsFlipped,
            masteredCards,
            categoriesCompleted,
            currentStreak,
            aiHelpCount,
            unlockedBadges,
          }}
        />
      )}

      {achievementToShow && (
        <AchievementToast
          title={achievementToShow.title}
          icon={achievementToShow.icon}
          onClose={() => setAchievementToShow(null)}
        />
      )}

      <main className="flex-1 flex flex-col items-center justify-center p-4 md:p-6 relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[var(--color-primary-blue)] rounded-full blur-[150px] opacity-10 pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[var(--color-secondary-blue)] rounded-full blur-[150px] opacity-10 pointer-events-none" />

        {!activeCategory ? (
          // --- Category Selection View ---
          <div className="w-full max-w-6xl animate-fade-in">
            <div className="text-center mb-8 md:mb-12">
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-4 text-balance">
                Master Any Subject <br />
                <span className="text-[var(--color-primary-blue)]">One Card at a Time</span>
              </h1>
              <p className="text-gray-400 text-base md:text-lg">Select a category to begin your journey</p>

              <div className="flex justify-center gap-6 mt-6 text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-gray-500">Cards Mastered:</span>
                  <span className="text-[var(--color-primary-blue)] font-bold">{masteredCards}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-500">Level:</span>
                  <span className="text-[var(--color-primary-blue)] font-bold">{level}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              {Object.values(STUDY_DATA).map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleCategorySelect(cat.id)}
                  className="group relative bg-[var(--color-card-bg)] border border-white/10 p-6 md:p-8 rounded-2xl text-left transition-all hover:-translate-y-2 hover:border-[var(--color-primary-blue)] hover:shadow-[0_0_30px_rgba(0,242,255,0.15)] active:scale-95"
                >
                  <div className="text-3xl md:text-4xl mb-3 md:mb-4 transform group-hover:scale-110 transition-transform duration-300">
                    {cat.icon}
                  </div>
                  <h3 className="text-lg md:text-xl font-bold mb-2 text-white group-hover:text-[var(--color-primary-blue)] transition-colors text-balance">
                    {cat.title}
                  </h3>
                  <p className="text-xs md:text-sm text-gray-500 group-hover:text-gray-300 transition-colors text-balance">
                    {cat.subtitle}
                  </p>
                </button>
              ))}
            </div>
          </div>
        ) : (
          // --- Study View ---
          <div className="w-full max-w-4xl animate-fade-in flex flex-col items-center">
            <div className="w-full flex flex-col md:flex-row justify-between items-center mb-8 md:mb-10 gap-4">
              <button
                onClick={handleBack}
                className="text-gray-400 hover:text-white hover:underline flex items-center gap-2 transition-colors self-start md:self-auto"
              >
                ← Back to Categories
              </button>

              <div className="flex gap-2 bg-[#111] p-1 rounded-full border border-white/10">
                {(["easy", "normal", "hard"] as Level[]).map((lvl) => {
                  const isUnlocked = isDifficultyUnlocked(lvl)
                  return (
                    <button
                      key={lvl}
                      onClick={() => isUnlocked && handleLevelChange(lvl)}
                      disabled={!isUnlocked}
                      className={cn(
                        "px-3 md:px-4 py-1.5 rounded-full text-sm font-medium transition-all capitalize flex items-center gap-1",
                        activeLevel === lvl
                          ? "bg-[var(--color-primary-blue)] text-black shadow-[0_0_15px_rgba(0,242,255,0.4)]"
                          : isUnlocked
                            ? "text-gray-400 hover:text-white"
                            : "text-gray-600 cursor-not-allowed opacity-50",
                      )}
                      title={!isUnlocked ? `Unlock at Level ${lvl === "normal" ? 4 : 7}` : ""}
                    >
                      {!isUnlocked && <span className="text-xs">🔒</span>}
                      {lvl}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="w-full">
              {currentQuestions.length > 0 ? (
                <Flashcard
                  data={currentCard}
                  onNext={handleNextCard}
                  onMastered={handleMastered}
                  onNeedsPractice={handleNeedsPractice}
                  onFlip={handleCardFlip}
                />
              ) : (
                <div className="text-center text-gray-500 p-10 border border-white/10 rounded-xl">
                  No questions available for this level.
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </>
  )
}
