import type React from "react"
import type { Metadata } from "next"
import { AdminSidebar } from "@/components/admin-sidebar"
// 1. Import the component
import { WatsonxAssistant } from "@/components/watsonx-assistant" 

export const metadata: Metadata = {
  title: "Admin Dashboard - StudyFriendly",
  description: "Administrative panel for StudyFriendly",
}

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <AdminSidebar />
      <main className="pl-64 min-h-screen bg-gradient-to-br from-black to-gray-900">
        <div className="p-8 max-w-7xl mx-auto animate-fade-in">{children}</div>
      </main>
      
      {/* 2. Add the component here so it loads on every admin page */}
      <WatsonxAssistant />
    </div>
  )
}
