"use client"

import {
  MOCK_OVERVIEW,
  MOCK_DAILY_STATS,
  MOCK_CATEGORY_STATS,
  MOCK_FEEDBACK,
  MOCK_AI_STATS,
} from "@/lib/mock-admin-data"
import {
  StatCard,
  GrowthChart,
  CategoryChart,
  ActivityHeatmap,
  FeedbackList,
  AiStatsWidget,
  DeviceStats,
  RegionStats,
} from "@/components/admin/dashboard-widgets"
import { Users, BookOpen, Zap, TrendingUp, Download, Calendar, ArrowUpRight } from "lucide-react"
import Link from "next/link"

export default function AdminDashboard() {
  return (
    <div className="flex flex-col gap-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-1">Dashboard Overview</h1>
          <p className="text-gray-400 text-sm">Welcome back, Admin. Here's what's happening today.</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-sm transition-colors">
            <Calendar className="w-4 h-4 text-gray-400" />
            <span>Last 7 Days</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-[var(--color-primary-blue)] hover:bg-cyan-400 text-black font-bold rounded-lg text-sm transition-colors">
            <Download className="w-4 h-4" />
            Export Report
          </button>
        </div>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Users"
          value={MOCK_OVERVIEW.totalUsers.toLocaleString()}
          change="+12.5%"
          trend="up"
          icon={Users}
          color="text-blue-400"
        />
        <StatCard
          title="Active Today"
          value={MOCK_OVERVIEW.activeToday.toLocaleString()}
          change="+5.2%"
          trend="up"
          icon={Zap}
          color="text-yellow-400"
        />
        <StatCard
          title="Cards Viewed"
          value={MOCK_OVERVIEW.totalCardsViewed.toLocaleString()}
          change="+18.2%"
          trend="up"
          icon={BookOpen}
          color="text-purple-400"
        />
        <StatCard
          title="XP Earned"
          value={MOCK_OVERVIEW.totalXpEarned.toLocaleString()}
          change="+24.5%"
          trend="up"
          icon={TrendingUp}
          color="text-green-400"
        />
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* User Growth & Activity */}
        <div className="lg:col-span-2 bg-[var(--color-card-bg)] border border-white/10 rounded-2xl p-6">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-lg font-bold text-white">User Growth</h2>
            <div className="flex items-center gap-4">
              <Link
                href="/analytics"
                className="flex items-center gap-1 text-xs text-[var(--color-primary-blue)] hover:underline"
              >
                View Full Analytics <ArrowUpRight className="w-3 h-3" />
              </Link>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-[var(--color-primary-blue)] rounded-full" /> Active Users
                </span>
              </div>
            </div>
          </div>
          <GrowthChart data={MOCK_DAILY_STATS} />
        </div>

        {/* Top Categories */}
        <div className="bg-[var(--color-card-bg)] border border-white/10 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-white mb-2">Top Categories</h2>
          <CategoryChart data={MOCK_CATEGORY_STATS} />
        </div>
      </div>

      {/* Analytics Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Study Heatmap */}
        <div className="bg-[var(--color-card-bg)] border border-white/10 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-white mb-1">Study Time Heatmap</h2>
          <p className="text-xs text-gray-500 mb-4">When users are most active (UTC)</p>
          <ActivityHeatmap />
        </div>

        {/* User Demographics */}
        <div className="bg-[var(--color-card-bg)] border border-white/10 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-white mb-2">User Demographics</h2>
          <div className="space-y-6">
            <div>
              <h3 className="text-xs font-bold text-gray-500 uppercase mb-2">Device Usage</h3>
              <DeviceStats />
            </div>
            <div>
              <h3 className="text-xs font-bold text-gray-500 uppercase mb-2">Region</h3>
              <RegionStats />
            </div>
          </div>
        </div>

        {/* AI Stats */}
        <div className="bg-[var(--color-card-bg)] border border-white/10 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-white mb-1">AI Assistant Usage</h2>
          <p className="text-xs text-gray-500 mb-2">Orchestrate interactions & efficiency</p>
          <AiStatsWidget stats={MOCK_AI_STATS} />
        </div>
      </div>

      {/* Feedback & Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[var(--color-card-bg)] border border-white/10 rounded-2xl p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-bold text-white">Recent Feedback</h2>
            <button className="text-xs text-[var(--color-primary-blue)] hover:underline">View All</button>
          </div>
          <FeedbackList items={MOCK_FEEDBACK} />
        </div>

        <div className="bg-[var(--color-card-bg)] border border-white/10 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-white mb-4">System Logs & Errors</h2>
          <div className="space-y-2 font-mono text-xs">
            <div className="flex gap-3 p-2 bg-red-500/10 border border-red-500/20 rounded text-red-300">
              <span className="shrink-0 opacity-50">10:42 AM</span>
              <span>Error: Failed to load audio resource [id:7721]</span>
            </div>
            <div className="flex gap-3 p-2 bg-yellow-500/10 border border-yellow-500/20 rounded text-yellow-300">
              <span className="shrink-0 opacity-50">09:15 AM</span>
              <span>Warning: High latency on AI endpoint (1200ms)</span>
            </div>
            <div className="flex gap-3 p-2 bg-blue-500/10 border border-blue-500/20 rounded text-blue-300">
              <span className="shrink-0 opacity-50">08:30 AM</span>
              <span>Info: Scheduled maintenance completed successfully</span>
            </div>
            <div className="flex gap-3 p-2 bg-white/5 border border-white/10 rounded text-gray-400">
              <span className="shrink-0 opacity-50">08:00 AM</span>
              <span>System: Daily backup created (2.4GB)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
